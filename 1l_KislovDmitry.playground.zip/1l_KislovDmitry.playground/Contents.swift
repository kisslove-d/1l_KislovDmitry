import UIKit


// 1. Решение квадратного уравнения
// a*x^2 + b*x + c = 0, a != 0

var a: Double = 5
var b: Double = 7
var c: Double = -8

let x1: Double
let x2: Double
let discriminant: Double = b * b - 4 * a * c

if (discriminant > 0) {
    x1 = -b + sqrt(discriminant) / (2 * a)
    x2 = -b - sqrt(discriminant) / (2 * a)
    print("Уравнение имеет 2 корня: x1 = \(x1), x2 = \(x2)")
} else if (discriminant == 0) {
    x1 = -b / (2 * a)
    print("Уравнение имеет 1 корень: х1 = \(x1)")
} else {
    print("Уравнение не имеет корней.")
}


// 2. Даны катеты прямоугольного треугольника. Найти площадь, периметр и гипотенузу треугольника.

var katet1 = 4
var katet2 = 7
print("Катет 1 = \(katet1), катет 2 = \(katet2)")

// Гипотенуза треугольника
var hypotenuz = sqrt(Double(katet1 * katet1 + katet2 * katet1))
hypotenuz = Double(round(hypotenuz * 100) / 100)
print("Гипотенуза = \(hypotenuz)")

// Периметр треугольника
var perimeter = Double(katet1) + Double(katet2) + hypotenuz
print("Периметр треугольника = \(perimeter)")

// Площадь треугольника
var area = Double(katet1 * katet2) / 2
print("Площадь треугольника = \(area)")


// Пользователь вводит сумму вклада в банк и годовой процент. Найти сумму вклада через 5 лет.

var summ: Double = 10000
var percent: Double = 7
summ = summ + (summ * percent / 100)
summ += (summ * percent / 100)
summ += (summ * percent / 100)
summ += (summ * percent / 100)
summ += (summ * percent / 100)
print("Сумма вклада через 5 лет составит \(summ)")

